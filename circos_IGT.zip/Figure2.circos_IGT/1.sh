ref=RZ_scaffold1.fa
qry=mhmt.fasta

######################################################
#kayotype
cat Actinidia_chinensis_cp_genome.fasta RZmt.fasta MHmt.fasta DHmt2.fasta DHmt1.fasta > genome.fa
perl /linux_u_disk/bin/circos_create_karyotype_by_genome.pl genome.fa > kayotype.txt
cat band.txt >> kayotype.txt
#circos.conf
pwd=`pwd`
echo "
# 指定染色体组型的文件，该文件为
karyotype = $pwd/kayotype.txt
# 设置长度单位，以下设置表示 1M 长度的序列代表为 1u。
chromosomes_units = 1000
# 默认设置下是将 karyotype 文件中所有的染色体都展示出来。当然，也可能根据需要仅展示指定的 chromosomes, 使用如下的参数进行设置。
#chromosomes_display_default = no
chromosomes_display_default = yes
# 以下参数设置指定的 chromosomes 用于展示到圈图中。// 中是一个正则表达式，匹配的 chromosomes 用于展示到圈图中。其匹配的对象是 karyotype 文件中的第 3 列。也可以直接列出需要展示的 chromosomes， 例如：hs1;hs2;hs3;hs4 。
#chromosomes = LE01Scaffold0001;LE01Scaffold0002;LE01Scaffold0003
#chromosomes                 = /hs[1-4]$/
# chromosomes                 = hs1;hs2;hs3;hs4
#chromosomes = /Supercontig_[1-7]$/
# 以下设置各个 ideograms 的大小。其总长度为 1 ，hs1 的长度为 0.5， hs2，hs3 和 hs4 这 3 个 chromosomes 的总长度为 0.5，并且这 3 个 chromosomes 的长度是分布均匀的。注意前者的单位是 r，后者使用了正则表达式对应多个 chromosomes， 其单位于是为 rn 。
#chromosomes_scale   = hs1=0.5r,/hs[234]/=0.5rn
# 使 hs2， hs3 和 hs4 在圈图上的展示方向是反向的。
#chromosomes_reverse = /hs[234]/
# 设置各个 ideograms 的颜色
#chromosomes_color   = hs1=red,hs2=orange,hs3=green,hs4=blue
# 默认下在 ideogram block 中统一设置了 ideogram 的位置，可以使用此参数调整指定 ideogram 的位置。
# chromosomes_radius  = hs4:0.9r
# chromosomes_radius  = hs2:0.9r;hs3:0.8r;hs4:0.7r
# karyotype 文件最后一列指定了各个 chromosomes 的颜色，而使用 chromosomes_color 参数也能修改颜色。当然，使用如下方式进行颜色的修改，则更加直观。以下方式是对>颜色重新进行定义。chr1，chr2，chr3 和 chr4 对应着 karyotype 文件最后一列的值，代表着颜色的类型。此处使用 color block 来对其进行重新定义。注意重新定义的时候需要加符号 *
<colors>
#chr23* = chrx
chr1* = red
chr2* = orange
chr3* = green
chr4* = blue
chr5* = blue
#black,blackweak,
#vdgrey_a4,vvlgrey,vlgrey,lgrey,grey,
</colors>
#染色体翻转
chromosomes_reverse = /DHmt[12]/
chromosomes_radius  = NC_026690.1:0.9r

show_links      = yes

### 绘制 plot 图
<plots>

#<<include plots_histogram.conf>>
#<<include plots_heatmap.conf>>
#<<include plots_text.conf>>

</plots>

<<include ideogram.conf>>
<<include ticks.conf>>
#<<include links.conf>>

<links>

show          = conf(show_links)
ribbon        = yes
#flat          = yes
radius        = 0.99r
bezier_radius = 0r
#color         = black_a5

<link>
file = bundle.txt
#<<include link.rules.conf>>
</link>

</links>

<plot>
show_links     = yes
link_dims      = 4p,2p,5p,2p,2p
link_thickness = 2p
link_color     = grey
</plot>





# 插入必须的并不常修改的标准参数
<image>
<<include etc/image.conf>>
</image>
<<include etc/colors_fonts_patterns.conf>>
<<include etc/housekeeping.conf>>
" > circos.conf
#ideogram.conf
echo "
<ideogram>

<spacing>
# 设置圈图中染色体之间的空隙大小，以下设置为每个空隙大小为周长的 0.5%
default = 0.002r
# default = 20u
# 也可以设置指定两条染色体之间的空隙
<pairwise Supercontig_1;Supercontig_7>
# 以下设定为两条染色体之间的空隙约为圆的 20 度角。
spacing = 10r
</pairwise>
</spacing>
## 设定 ideograms
# 设定 ideograms 的位置，以下设定 ideograms 在图离圆心的 90% 处
radius           = 0.90r
# 设定 ideograms 的厚度，可以使用 r（比例关系） 或 p（像素）作为单位
thickness        = 20p
# 设定 ideograms 是否填充颜色。填充的颜色取决于 karyotype 指定的文件的最后一列。
fill             = yes
# 设定 ideograms 轮廓的颜色及其厚度。如果没有该参数或设定其厚度为0，则表示没有轮廓。
stroke_color     = dgrey
stroke_thickness = 2p

## 设定 label 的显示
# 设定是否显示 label 。 label 对应着 karyotype 文件的第 4 列。如果其值为 yes，则必须要有 label_radius 参数来设定 label 的位置，否则会报错并不能生成结果。
show_label       = yes
# 设定 label 的字体
label_font       = default
# 设定 label 的位置
label_radius     = 1r+90p
# 设定 label 的字体大小
label_size       = 40
# 设定 label 的字体方向，yes 是易于浏览的方向。
label_parallel   = no

# 显示 bands 信息
show_bands            = yes
# 对 bands 部分进行颜色填充
fill_bands            = yes
# 设定 bands 廓的厚度、颜色和透明度
band_stroke_thickness = 0
band_stroke_color     = black
band_transparency     = 1

</ideogram>
" > ideogram.conf
#links.conf
echo "
<links>
<link>
# 指定 link 文件的路径
file          = mt.cp.block
radius        = 0.99r
# 设置贝塞尔曲线半径，该值设大后曲线扁平，使图像不太好看。
bezier_radius = 0r
# 设置 link 曲线的颜色
color         = orange
# 设置 link 曲线的厚度
#thickness     = 3
# 设置弯曲程度
crest  = 1
# 是否呈带状显示
ribbon        = yes
# 渐变显示
flat          = yes
</link>

</links>
" > links.conf

#ticks.conf
echo "
# 是否显示 ticks
show_ticks         = yes
# 是否显示 ticks 的 lables
show_tick_labels    = yes

## 设定 ticks
<ticks>
## ticks 的设置
# 设定 ticks 的位置
radius           = 1r
# 设定 ticks 的颜色
color            = black
# 设定 ticks 的厚度
thickness        = 2p
# 设定 ticks' label 的值的计算。将该刻度对应位置的值 * multiplier 得到能展示到圈图上的 label 值。
multiplier       = 1e-3
# label 值的格式化方法。%d 表示结果为整数；%f 结果为浮点数； %.1f 结果为小数点后保留1位； %.2f 结果为小数点后保留2位。
format           = %d

## 以下设置了 2 个 ticks，前者是小刻度，后者是大刻度。
<tick>
# 设置每个刻度代表的长度。若其单位为 u，则必须要设置 chromosomes_units 参数。比如设置 chromosomes_units = 1000000，则如下 5u 表示每个刻度代表 5M 长度的基因组序列。
spacing        = 5u
# 设置 tick 的长度
size           = 10p
</tick>

<tick>
spacing        = 20u
size           = 20p
# 由于设置的是大刻度，以下用于设置展示 ticks' label。
show_label     = yes
# 设置 ticks' label 的字体大小
label_size     = 20p
# 设置 ticks' label 离 ticks 的距离
label_offset   = 10p
format         = %d
</tick>

</ticks>
" > ticks.conf

circos -noparanoid -conf circos.conf


